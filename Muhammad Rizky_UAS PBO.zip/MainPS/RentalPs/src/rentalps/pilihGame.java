
package rentalps;


public class pilihGame {
    String kategoriGame;
    String namaGame;
    double versiTahun;
    
    
    public void gameHD(){
        this.namaGame = "God Of War 4";
    }
}
