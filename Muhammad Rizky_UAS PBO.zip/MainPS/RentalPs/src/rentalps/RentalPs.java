
package rentalps;


public class RentalPs {

   
    public static void main(String[] args) {
        pilihGame gamePerang = new pilihGame();
        gamePerang.kategoriGame = "Game Tembak";
        gamePerang.namaGame = "Black Ops";
        gamePerang.versiTahun = 2020;
        
        pilihGame gameOlahraga = new pilihGame();
        gameOlahraga.kategoriGame = "Game Bola";
        gameOlahraga.namaGame = "Fifa 2021";
        gameOlahraga.versiTahun = 2021;
        
        System.out.println(gameOlahraga.namaGame);
        
        System.out.println(gamePerang.namaGame);
        
        System.out.println(gamePerang.kategoriGame);
    }
    
}
